#include <SFML\Graphics.hpp>
#include <SFML/Network.hpp>
#include <string>
#include <cstring>
#include <iostream>
#include <vector>
#include <mutex>
#include <thread>
#include <list>

#define MAX_MENSAJES 30
#define MY_IP "10.40.0.1"
#define PORT 52000

////////////////////////////////////////////////////////////////////////// VECTOR DE MENSAJES
std::vector<std::string> aMensajes;
bool finish = false;

std::mutex myMutex;

//exercici 4


void receptionFunction(sf::TcpSocket *mySocket)
{
	
	sf::Packet myPacket;
	std::string newMessage;

	sf::Socket::Status status;

	while(!finish)
	{
		status = mySocket->receive(myPacket);
		if (status == sf::Socket::Disconnected)
		{
			finish = true;
			std::cout << "El otro usuario se ha desconectado de forma repentina" << std::endl;
		}
		myPacket >> newMessage;

		if (newMessage == "Client: >exit")
		{
			finish = true;
		}

		std::cout << newMessage << std::endl;
		myMutex.lock();
		aMensajes.push_back(newMessage);
		myMutex.unlock();
		///////////////////////////////////////////////////////////////////////////////////////////SI EL VECTOR "aMEnsajes" ES MAYOR A 25 BORRAMOS LA PRIMERA POSICION QUE ES EL MENSAJE MAS ANTIGUO
		if (aMensajes.size() > 25)
		{
			myMutex.lock();
			aMensajes.erase(aMensajes.begin(), aMensajes.begin() + 1);
			myMutex.unlock();
		}

	}
	
}

//////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////SERVIDOR
//////////////////////////////////////////////////////////////////////////////////////////////

void ControlServidor(sf::TcpListener* listener, sf::TcpSocket* client)
{
	bool running = true;
	// Create a socket to listen to new connections
	// Create a selector
	sf::SocketSelector selector;
	//selector.add(*listener);
	selector.add(*client);
	// Add the listener to the selector
	// Endless loop that waits for new connections
	while (running)
	{
		
		if (selector.wait() && selector.isReady(*client))
		{
			// The client has sent some data, we can receive it
			sf::Packet packet;
			sf::Socket::Status status;
			status = client->receive(packet);
			if (status == sf::Socket::Done)
			{
				std::string strRec;
				packet >> strRec;
				std::cout << "He recibido " << strRec << " del puerto " << client->getRemotePort() << std::endl;
				aMensajes.push_back(strRec);
				///////////////////////////////////////////////////////////////////////////////////////////SI EL VECTOR "aMEnsajes" ES MAYOR A 25 BORRAMOS LA PRIMERA POSICION QUE ES EL MENSAJE MAS ANTIGUO
				if (aMensajes.size() > 25)
				{
					aMensajes.erase(aMensajes.begin(), aMensajes.begin() + 1);
				}
			}
			else if (status == sf::Socket::Disconnected)
			{
				selector.remove(*client);
				//delete client;
				std::cout << "Elimino el socket que se ha desconectado\n";
				finish = true;
			}
			else
			{
				std::cout << "Error al recibir de " << client->getRemotePort() << std::endl;
			}
		}
	}

}

int main()
{
	int mode = 0;
	std::string newMessage;
	//////////////////////////////////////////////////////////////////////////CREAMOS LA VENTATA
	sf::Vector2i screenDimensions(800, 600);

	sf::RenderWindow window;
	window.create(sf::VideoMode(screenDimensions.x, screenDimensions.y), "Chat <Server> ");

	sf::Font font;
	if (!font.loadFromFile("courbd.ttf"))
	{
		std::cout << "Can't load the font file" << std::endl;
	}

	std::string mensaje = ">";

	//////////////////////////////////////////////////////////////////////////TEXTO DEL CHAT COMPLETO
	sf::Text chattingText(mensaje, font, 14);
	chattingText.setFillColor(sf::Color(0, 160, 0));
	chattingText.setStyle(sf::Text::Bold);

	//////////////////////////////////////////////////////////////////////////TEXTO DEL CHAT QUE ESCRIBE EL USUARIO
	sf::Text text(mensaje, font, 14);
	text.setFillColor(sf::Color(0, 160, 0));
	text.setStyle(sf::Text::Bold);
	text.setPosition(0, 560);
	//////////////////////////////////////////////////////////////////////////PINTAMSO EL SEPARADOR ENTRE EL LA ESCRITURA Y EL CHAT
	sf::RectangleShape separator(sf::Vector2f(800, 5));
	separator.setFillColor(sf::Color(200, 200, 200, 255));
	separator.setPosition(0, 550);



	///////////////////////////////////////////////////////////////////////////PREGUNTAMOS EN QUE MODO QUEREMOS ABRIR EL CHAT
	bool modeSelected = false;
	std::string answer;
	do {

		std::cout << "En que modo quieres abrir el chat? \n		1.Blocking + Threading \n		2.NonBlocking \n		3.Blocking + SocketSeletor" << std::endl;
		std::cin >> answer;

		if (answer == "1")
		{
			modeSelected = true;
			mode = 1;
			std::cout << "Has escogido el modo Blocking + Threading \n" << std::endl;
			

		}
		else if (answer == "2")
		{
			modeSelected = true;
			mode = 2;
			std::cout << "Has escogido el modo NonBlocking\n" << std::endl;

		}
		else if (answer == "3")
		{
			modeSelected = true;
			mode = 3;
			std::cout << "Has escogido el modo Blocking + SocketSeletor \n" << std::endl;
		}

		else std::cout << "Respuesta incorrecta. Vuelve a intentarlo" << std::endl;

	} while (!modeSelected);

	
	sf::Packet myPacket;

	sf::TcpListener dispatcher;

	sf::Socket::Status status;

	sf::TcpSocket incoming;
	/////////////////////////////////////////////////////////////////////////////////////////////////////////BLOCKING && THREADING
	if (mode == 1)
	{
		////////////////////////////////////////////////////////////////////////////CREAMOS EL LISTENER
		status = dispatcher.listen(PORT);
		if (status != sf::Socket::Done)
		{
			std::cout << "No se ha podido vincular el Puerto" << std::endl;
		}
		else std::cout << "Se ha podido vincular el Puerto" << std::endl;


		if (dispatcher.accept(incoming) != sf::Socket::Done)
		{
			std::cout << "error al aceptar la conexion" << std::endl;
		}
		else std::cout << "Se ha aceptado la conexion correctamente" << std::endl;
		////////////////////////////////////////////////////////////////////////////////LANZAMOS EL THREAD DE RECEPCION
		std::thread t(&receptionFunction, &incoming);
		t.detach();
		////////////////////////////////////////////////////////////////////////////////ENVIAMOS AL CLIENTE EL MODO DE CHAT
		myPacket << answer;

		status = incoming.send(myPacket);	

		myPacket.clear();
		if (status != sf::Socket::Done)
		{
			std::cout << "No se ha podido enviar correctamente la informacion del modo en el que esta el chat" << std::endl;
		}
		if (status == sf::Socket::Done) std::cout << "Se ha podido enviar correctamente la informacion del modo en el que esta el chat" << std::endl;


	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////NONBLOCKING
	else if (mode == 2)
	{
		
		////////////////////////////////////////////////////////////////////////////CREAMOS EL LISTENER
		status = dispatcher.listen(PORT);
		if (status != sf::Socket::Done)
		{
			std::cout << "No se ha podido vincular el Puerto" << std::endl;
		}
		else std::cout << "Se ha podido vincular el Puerto" << std::endl;

		

		if (dispatcher.accept(incoming) != sf::Socket::Done)
		{
			std::cout << "error al aceptar la conexion" << std::endl;
		}
		else std::cout << "Se ha aceptado la conexion correctamente" << std::endl;

		incoming.setBlocking(false);

		if (status != sf::Socket::Done)
		{
			std::cout << "error al aceptar la conexion" << std::endl;
		}
		else std::cout << "Se ha aceptado la conexion correctamente" << std::endl;

		////////////////////////////////////////////////////////////////////////////////ENVIAMOS AL CLIENTE EL MODO DE CHAT
		myPacket << answer;

		status = incoming.send(myPacket);

		//if (status == sf::Socket::Partial)
		//{

		//	do {
		//		status = incoming.send(myPacket);

		//	} while (status == sf::Socket::Done);
		//}

		do {
			status = incoming.send(myPacket);
		} while (status == sf::Socket::Partial);
		myPacket.clear();

		if (status != sf::Socket::Done)
		{
			std::cout << "No se ha podido enviar correctamente la informacion del modo en el que esta el chat" << std::endl;
		}
		if (status == sf::Socket::Done) std::cout << "Se ha podido enviar correctamente la informacion del modo en el que esta el chat" << std::endl;


	}
	else if (mode == 3)
	{

		////////////////////////////////////////////////////////////////////////////CREAMOS EL LISTENER
		status = dispatcher.listen(PORT);
		if (status != sf::Socket::Done)
		{
			std::cout << "No se ha podido vincular el Puerto" << std::endl;
		}
		else std::cout << "Se ha podido vincular el Puerto" << std::endl;



		if (dispatcher.accept(incoming) != sf::Socket::Done)
		{
			std::cout << "error al aceptar la conexion" << std::endl;
		}
		else std::cout << "Se ha aceptado la conexion correctamente" << std::endl;

		incoming.setBlocking(false);

		////////////////////////////////////////////////////////////////////////////////ENVIAMOS AL CLIENTE EL MODO DE CHAT
		myPacket << answer;

		status = incoming.send(myPacket);
		////////////////////////////////////////////////////////////////////////////////LANZAMOS EL THREAD DE RECEPCION
		std::thread t(&ControlServidor, &dispatcher, &incoming);
		t.detach();
	}
		
	myPacket.clear();
	////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////---------------COMIENZA EL CHAT
	////////////////////////////////////////////////////////////////////////////////////////////////////////////
	while (window.isOpen() && !finish)
	{
		////////////////////////////////////////////////////////////////////////RECIEVE DEL MODO NONBLOCKING
		if (mode == 2)
		{
			status = incoming.receive(myPacket);
			if (status == sf::Socket::Done)
			{

				myPacket >> newMessage;

				if (newMessage == "Client: >exit")
				{
					finish = true;
				}

				std::cout << newMessage << std::endl;
				
				aMensajes.push_back(newMessage);
				
				///////////////////////////////////////////////////////////////////////////////////////////SI EL VECTOR "aMEnsajes" ES MAYOR A 25 BORRAMOS LA PRIMERA POSICION QUE ES EL MENSAJE MAS ANTIGUO
				if (aMensajes.size() > 25)
				{
					
					aMensajes.erase(aMensajes.begin(), aMensajes.begin() + 1);
					
				}
			}			
			else if (status == sf::Socket::Disconnected)
			{
				finish = true;
				std::cout << "El otro usuario se ha desconectado de forma repentina" << std::endl;
			}
		}
		

		sf::Event evento;
		while (window.pollEvent(evento))
		{
			switch (evento.type)
			{
			case sf::Event::Closed:
				window.close();
				break;
			case sf::Event::KeyPressed:
				///////////////////////////////////////////////////////////////////////////////////////////////CUANDO SE APRETA A ESCAPE SE CIERRA LA VENTANA
				if (evento.key.code == sf::Keyboard::Escape)
					window.close();
				///////////////////////////////////////////////////////////////////////////////////////////////CUANDO SE APRETA A ENTER, LA VARIABLE "mensaje" SE A�ADE AL VECTOR DE MENSAJES DONDE ESTA TODO EL CHAT
				else if (evento.key.code == sf::Keyboard::Return)
				{
					mensaje = "Server: " + mensaje;
									
					aMensajes.push_back(mensaje);					
					
 
					myPacket << mensaje;

					if (mode == 1 || mode == 3)
					{
						status = incoming.send(myPacket);
					}
					else if (mode ==2)
					{
						do {
							status = incoming.send(myPacket);
						} while (status == sf::Socket::Partial);
					}
					myPacket.clear();

					if (mensaje == "Server: >exit")
					{
						window.close();
					}

					///////////////////////////////////////////////////////////////////////////////////////////SI EL VECTOR "aMEnsajes" ES MAYOR A 25 BORRAMOS LA PRIMERA POSICION QUE ES EL MENSAJE MAS ANTIGUO
					if (aMensajes.size() > 25)
					{
					
						aMensajes.erase(aMensajes.begin(), aMensajes.begin() + 1);
						
					}
					mensaje = ">";
				}
				break;
			case sf::Event::TextEntered:
				///////////////////////////////////////////////////////////////////////////SE VA GUARDANDO CADA LETRA QUE ESCRIBE EL USUARIO EN LA VARIABLE "mensaje"
				if (evento.text.unicode >= 32 && evento.text.unicode <= 126)
					mensaje += (char)evento.text.unicode;
				///////////////////////////////////////////////////////////////////////////BORRA DE LA VARIABLE "mensaje" 
				else if (evento.text.unicode == 8 && mensaje.length() > 0)
					mensaje.erase(mensaje.length() - 1, mensaje.length());
				break;
			}
		}
		window.draw(separator);
		//////////////////////////////////////////////////////////////////////////////////PINTAMOS EL CHAT COMPLETO
		for (size_t i = 0; i < aMensajes.size(); i++)
		{
			myMutex.lock();
			std::string chatting = aMensajes[i];
			myMutex.unlock();
			chattingText.setPosition(sf::Vector2f(0, 20 * i));
			chattingText.setString(chatting);
			window.draw(chattingText);
		}

		////////////////////////////////////////////////////////////////////////////////////PINTAMOS EL CURSOR DE ESCRITURA
		std::string mensaje_ = mensaje + "_";
		text.setString(mensaje_);
		window.draw(text);

		

		window.display();
		window.clear();
	}
	//////////////////////////////////////LIBERANDO LOS RECURSOS
	incoming.disconnect();
	dispatcher.close();


	//system("pause");
}